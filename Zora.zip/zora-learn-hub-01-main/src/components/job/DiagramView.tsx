import * as React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type DiagramContent = {
  mermaid?: string;
  alt_text?: string;
  image_bucket?: string;
  image_path?: string;
};

function asDiagramContent(value: unknown): DiagramContent | null {
  if (!value || typeof value !== "object") return null;
  const v = value as any;
  return {
    mermaid: typeof v.mermaid === "string" ? v.mermaid : undefined,
    alt_text: typeof v.alt_text === "string" ? v.alt_text : undefined,
    image_bucket: typeof v.image_bucket === "string" ? v.image_bucket : undefined,
    image_path: typeof v.image_path === "string" ? v.image_path : undefined,
  };
}

export function DiagramView({ jobId, content }: { jobId: string; content: unknown }) {
  const qc = useQueryClient();
  const diagram = asDiagramContent(content);

  if (!diagram) {
    return (
      <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
        Diagram output is not in the expected format.
      </div>
    );
  }

  const alt = diagram.alt_text?.trim() || "Diagram";

  const hasImage = Boolean(diagram.image_bucket && diagram.image_path);

  const signedUrlQuery = useQuery({
    queryKey: ["diagram_signed_url", diagram.image_bucket, diagram.image_path],
    enabled: Boolean(diagram.image_bucket && diagram.image_path),
    queryFn: async () => {
      const { data, error } = await supabase.storage
        .from(diagram.image_bucket!)
        .createSignedUrl(diagram.image_path!, 60 * 10);
      if (error) throw error;
      return data.signedUrl;
    },
  });

  const generateImage = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("zora-diagram-image", {
        body: { jobId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ["zora_artifacts", jobId] });
    },
  });

  const imageUrl = signedUrlQuery.data;

  return (
    <section className="space-y-4">
      <div className="space-y-1">
        <h2 className="text-base font-semibold tracking-tight">Alt text</h2>
        <p className="text-sm text-muted-foreground">{diagram.alt_text?.trim() || "No alt text provided."}</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <CardTitle className="text-base">Diagram</CardTitle>
            <div className="flex items-center gap-2">
              {!hasImage ? (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => generateImage.mutate()}
                  disabled={generateImage.isPending}
                >
                  {generateImage.isPending ? "Generating…" : "Generate diagram image"}
                </Button>
              ) : (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (!imageUrl) return;
                    const a = document.createElement("a");
                    a.href = imageUrl;
                    a.download = "diagram.png";
                    a.rel = "noreferrer";
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                  }}
                  disabled={!imageUrl || signedUrlQuery.isLoading}
                >
                  Download PNG
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {hasImage ? (
            signedUrlQuery.isLoading ? (
              <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">Loading diagram…</div>
            ) : signedUrlQuery.isError ? (
              <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
                Couldn’t load the diagram image.
              </div>
            ) : imageUrl ? (
              <img src={imageUrl} alt={alt} className="w-full rounded-md border bg-background" loading="lazy" />
            ) : (
              <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">No diagram image yet.</div>
            )
          ) : (
            <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
              This job was created before diagram images were enabled. Click “Generate diagram image”.
            </div>
          )}

          {generateImage.isError ? (
            <div className="mt-3 rounded-md border bg-muted/30 p-3 text-sm text-muted-foreground">
              Couldn’t generate the diagram image. Please try again.
            </div>
          ) : null}

          {generateImage.isSuccess ? (
            <div className="mt-3 rounded-md border bg-muted/30 p-3 text-sm text-muted-foreground">
              Diagram image generated—refreshing…
            </div>
          ) : null}
        </CardContent>
      </Card>

    </section>
  );
}
