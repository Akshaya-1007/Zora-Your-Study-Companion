import * as React from "react";

type NotesContent = {
  summary?: string;
  key_points?: string[];
  glossary?: { term: string; definition: string }[];
  exam_questions?: string[];
};

function asNotesContent(value: unknown): NotesContent | null {
  if (!value || typeof value !== "object") return null;
  const v = value as any;
  return {
    summary: typeof v.summary === "string" ? v.summary : undefined,
    key_points: Array.isArray(v.key_points) ? v.key_points.filter((x: any) => typeof x === "string") : undefined,
    glossary: Array.isArray(v.glossary)
      ? v.glossary
          .filter((g: any) => g && typeof g === "object")
          .map((g: any) => ({
            term: typeof g.term === "string" ? g.term : "",
            definition: typeof g.definition === "string" ? g.definition : "",
          }))
          .filter((g: any) => g.term || g.definition)
      : undefined,
    exam_questions: Array.isArray(v.exam_questions)
      ? v.exam_questions.filter((x: any) => typeof x === "string")
      : undefined,
  };
}

export function NotesView({ content }: { content: unknown }) {
  const notes = asNotesContent(content);

  if (!notes) {
    return (
      <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
        Notes are not in the expected format.
      </div>
    );
  }

  return (
    <section className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-base font-semibold tracking-tight">Summary</h2>
        <p className="text-sm leading-relaxed text-foreground">
          {notes.summary?.trim() ? notes.summary : "No summary yet."}
        </p>
      </div>

      <div className="space-y-2">
        <h2 className="text-base font-semibold tracking-tight">Key points</h2>
        {notes.key_points?.length ? (
          <ul className="list-disc space-y-2 pl-5 text-sm leading-relaxed">
            {notes.key_points.map((p, i) => (
              <li key={i}>{p}</li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No key points yet.</p>
        )}
      </div>

      <div className="space-y-2">
        <h2 className="text-base font-semibold tracking-tight">Glossary</h2>
        {notes.glossary?.length ? (
          <dl className="divide-y rounded-md border bg-background">
            {notes.glossary.map((g, i) => (
              <div key={i} className="grid gap-1 p-4 md:grid-cols-[220px_1fr]">
                <dt className="text-sm font-medium">{g.term || "(term)"}</dt>
                <dd className="text-sm text-muted-foreground">{g.definition || "—"}</dd>
              </div>
            ))}
          </dl>
        ) : (
          <p className="text-sm text-muted-foreground">No glossary yet.</p>
        )}
      </div>

      <div className="space-y-2">
        <h2 className="text-base font-semibold tracking-tight">Exam questions</h2>
        {notes.exam_questions?.length ? (
          <ol className="list-decimal space-y-2 pl-5 text-sm leading-relaxed">
            {notes.exam_questions.map((q, i) => (
              <li key={i}>{q}</li>
            ))}
          </ol>
        ) : (
          <p className="text-sm text-muted-foreground">No practice questions yet.</p>
        )}
      </div>
    </section>
  );
}
