import * as React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type FlashcardsContent = {
  cards?: { front: string; back: string }[];
};

function asFlashcardsContent(value: unknown): FlashcardsContent | null {
  if (!value || typeof value !== "object") return null;
  const v = value as any;
  const cards = Array.isArray(v.cards)
    ? v.cards
        .filter((c: any) => c && typeof c === "object")
        .map((c: any) => ({
          front: typeof c.front === "string" ? c.front : "",
          back: typeof c.back === "string" ? c.back : "",
        }))
        .filter((c: any) => c.front || c.back)
    : undefined;
  return { cards };
}

export function FlashcardsView({ content }: { content: unknown }) {
  const data = asFlashcardsContent(content);
  const cards = data?.cards ?? [];

  const [index, setIndex] = React.useState(0);
  const [showBack, setShowBack] = React.useState(false);

  React.useEffect(() => {
    setIndex(0);
    setShowBack(false);
  }, [content]);

  if (!data) {
    return (
      <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
        Flashcards are not in the expected format.
      </div>
    );
  }

  if (!cards.length) {
    return <p className="text-sm text-muted-foreground">No flashcards yet.</p>;
  }

  const card = cards[Math.min(index, cards.length - 1)];

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Card {index + 1} of {cards.length}
        </p>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setIndex((i) => Math.max(0, i - 1));
              setShowBack(false);
            }}
            disabled={index === 0}
          >
            Previous
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setIndex((i) => Math.min(cards.length - 1, i + 1));
              setShowBack(false);
            }}
            disabled={index === cards.length - 1}
          >
            Next
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">{showBack ? "Answer" : "Prompt"}</CardTitle>
        </CardHeader>
        <CardContent>
          <button
            type="button"
            className="w-full rounded-md border bg-background p-5 text-left text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => setShowBack((v) => !v)}
            aria-label={showBack ? "Show prompt" : "Show answer"}
          >
            <p className="whitespace-pre-wrap">{showBack ? card.back : card.front}</p>
            <p className="mt-3 text-xs text-muted-foreground">Tap to {showBack ? "flip" : "reveal"}</p>
          </button>
        </CardContent>
      </Card>
    </section>
  );
}
