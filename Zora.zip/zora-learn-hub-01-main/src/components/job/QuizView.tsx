import * as React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

type QuizQuestion = {
  q: string;
  choices: string[];
  answer_index: number;
  explanation?: string;
};

type QuizContent = {
  questions?: QuizQuestion[];
};

function asQuizContent(value: unknown): QuizContent | null {
  if (!value || typeof value !== "object") return null;
  const v = value as any;
  const questions = Array.isArray(v.questions)
    ? v.questions
        .filter((x: any) => x && typeof x === "object")
        .map((x: any) => ({
          q: typeof x.q === "string" ? x.q : "",
          choices: Array.isArray(x.choices) ? x.choices.filter((c: any) => typeof c === "string") : [],
          answer_index: typeof x.answer_index === "number" ? x.answer_index : -1,
          explanation: typeof x.explanation === "string" ? x.explanation : undefined,
        }))
        .filter((x: any) => x.q && x.choices.length)
    : undefined;
  return { questions };
}

export function QuizView({ content }: { content: unknown }) {
  const data = asQuizContent(content);
  const questions = data?.questions ?? [];

  const [index, setIndex] = React.useState(0);
  const [selected, setSelected] = React.useState<Record<number, number>>({});
  const [revealed, setRevealed] = React.useState<Record<number, boolean>>({});

  React.useEffect(() => {
    setIndex(0);
    setSelected({});
    setRevealed({});
  }, [content]);

  if (!data) {
    return (
      <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">Quiz is not in the expected format.</div>
    );
  }

  if (!questions.length) {
    return <p className="text-sm text-muted-foreground">No quiz yet.</p>;
  }

  const q = questions[Math.min(index, questions.length - 1)];
  const picked = selected[index];
  const isRevealed = Boolean(revealed[index]);
  const correct = q.answer_index;

  const score = Object.entries(selected).reduce((acc, [k, v]) => {
    const i = Number(k);
    const qq = questions[i];
    if (!qq) return acc;
    return acc + (v === qq.answer_index ? 1 : 0);
  }, 0);

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Question {index + 1} of {questions.length}
        </p>
        <p className="text-sm text-muted-foreground">Score: {score} / {questions.length}</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">{q.q}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <RadioGroup
            value={typeof picked === "number" ? String(picked) : ""}
            onValueChange={(val) => {
              const n = Number(val);
              if (!Number.isFinite(n)) return;
              setSelected((s) => ({ ...s, [index]: n }));
            }}
          >
            <div className="space-y-2">
              {q.choices.map((choice, i) => {
                const id = `q_${index}_c_${i}`;
                const isCorrect = isRevealed && i === correct;
                const isWrongPick = isRevealed && picked === i && i !== correct;

                return (
                  <div
                    key={id}
                    className={
                      "flex items-start gap-2 rounded-md border p-3" +
                      (isCorrect ? " bg-muted/30" : "") +
                      (isWrongPick ? " opacity-80" : "")
                    }
                  >
                    <RadioGroupItem value={String(i)} id={id} />
                    <Label htmlFor={id} className="cursor-pointer text-sm leading-relaxed">
                      {choice}
                      {isCorrect ? <span className="ml-2 text-xs text-muted-foreground">(correct)</span> : null}
                      {isWrongPick ? <span className="ml-2 text-xs text-muted-foreground">(your choice)</span> : null}
                    </Label>
                  </div>
                );
              })}
            </div>
          </RadioGroup>

          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setRevealed((r) => ({ ...r, [index]: true }))}
              disabled={typeof picked !== "number" || isRevealed}
            >
              Check answer
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIndex((i) => Math.max(0, i - 1));
              }}
              disabled={index === 0}
            >
              Previous
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIndex((i) => Math.min(questions.length - 1, i + 1));
              }}
              disabled={index === questions.length - 1}
            >
              Next
            </Button>
          </div>

          {isRevealed ? (
            <div className="rounded-md border bg-muted/30 p-4">
              <p className="text-sm font-medium">Explanation</p>
              <p className="mt-1 text-sm text-muted-foreground whitespace-pre-wrap">
                {q.explanation?.trim() ? q.explanation : "No explanation provided."}
              </p>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </section>
  );
}
