import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

type JobRow = {
  id: string;
  title: string;
  status: string;
  progress: number;
  created_at: string;
  error_message: string | null;
  storage_bucket: string;
  storage_path: string;
};

function statusTone(status: string) {
  if (status === "complete") return "secondary";
  if (status === "error") return "destructive";
  if (status === "processing") return "default";
  return "outline";
}

export default function DashboardPage() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const [title, setTitle] = useState("");
  const [transcript, setTranscript] = useState("");
  const [file, setFile] = useState<File | null>(null);

  const jobsQuery = useQuery({
    queryKey: ["zora_jobs"],
    queryFn: async (): Promise<JobRow[]> => {
      const { data, error } = await supabase
        .from("zora_jobs")
        .select("id,title,status,progress,created_at,error_message,storage_bucket,storage_path")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return (data ?? []) as JobRow[];
    },
  });

  const canSubmit = useMemo(() => {
    return Boolean(title.trim() && file);
  }, [title, file]);

  const createJob = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Choose a file first");
      const {
        data: { user },
        error: userErr,
      } = await supabase.auth.getUser();
      if (userErr) throw userErr;
      if (!user) throw new Error("Not signed in");

      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const storagePath = `${user.id}/${Date.now()}_${safeName}`;

      const up = await supabase.storage.from("zora-uploads").upload(storagePath, file, {
        contentType: file.type || undefined,
        upsert: false,
      });
      if (up.error) throw up.error;

      const ins = await supabase
        .from("zora_jobs")
        .insert({
          user_id: user.id,
          title: title.trim(),
          storage_path: storagePath,
          mime_type: file.type || null,
          status: "queued",
          progress: 0,
        })
        .select("id")
        .single();
      if (ins.error) throw ins.error;

      const jobId = (ins.data as any).id as string;

      // Start processing (best-effort). Transcript is optional but improves quality.
      const invoke = await supabase.functions.invoke("zora-process", {
        body: { jobId, transcript: transcript.trim() || null },
      });
      if (invoke.error) throw invoke.error;

      return jobId;
    },
    onSuccess: async (jobId) => {
      toast({ title: "Upload received", description: "We’re generating accessible study materials now." });
      setTitle("");
      setTranscript("");
      setFile(null);
      await qc.invalidateQueries({ queryKey: ["zora_jobs"] });
      // Optionally navigate to job page in future iteration
      void jobId;
    },
    onError: (err: any) => {
      toast({ title: "Couldn’t start processing", description: err?.message ?? "Please try again." });
    },
  });

  const deleteJob = useMutation({
    mutationFn: async (job: JobRow) => {
      // 1) Delete generated artifacts first (FK safety)
      const delArtifacts = await supabase.from("zora_artifacts").delete().eq("job_id", job.id);
      if (delArtifacts.error) throw delArtifacts.error;

      // 2) Delete the uploaded file (best-effort; if already missing, continue)
      const rm = await supabase.storage.from(job.storage_bucket).remove([job.storage_path]);
      if (rm.error && !String(rm.error.message ?? "").toLowerCase().includes("not found")) {
        throw rm.error;
      }

      // 3) Delete the job row
      const delJob = await supabase.from("zora_jobs").delete().eq("id", job.id);
      if (delJob.error) throw delJob.error;

      return job.id;
    },
    onSuccess: async () => {
      toast({ title: "Deleted", description: "The upload and job were removed from your workspace." });
      await qc.invalidateQueries({ queryKey: ["zora_jobs"] });
    },
    onError: (err: any) => {
      toast({ title: "Couldn’t delete", description: err?.message ?? "Please try again." });
    },
  });

  return (
    <AppShell>
      <main className="space-y-8">
        <header className="space-y-2">
          <h1 className="text-2xl font-semibold tracking-tight">Your study workspace</h1>
          <p className="text-sm text-muted-foreground">
            Upload a lecture recording (video/audio). If you have a transcript, paste it for best results.
          </p>
        </header>

        <section className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>New upload</CardTitle>
              <CardDescription>Creates notes, flashcards, quizzes, and a visual diagram.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Photosynthesis – Week 3" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="file">Video / audio file</Label>
                <Input
                  id="file"
                  type="file"
                  accept="video/*,audio/*"
                  onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                />
                <p className="text-xs text-muted-foreground">Files are stored securely in your private workspace.</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="transcript">Transcript (optional)</Label>
                <Textarea
                  id="transcript"
                  value={transcript}
                  onChange={(e) => setTranscript(e.target.value)}
                  placeholder="Leave blank to auto-transcribe from your audio/video (recommended)."
                  className="min-h-28"
                />
              </div>

              <div className="flex items-center justify-between gap-3">
                <Button onClick={() => createJob.mutate()} disabled={!canSubmit || createJob.isPending}>
                  {createJob.isPending ? "Processing…" : "Generate materials"}
                </Button>
                <p className="text-xs text-muted-foreground">
                  Tip: We can add automatic transcription next (speech-to-text).
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent jobs</CardTitle>
              <CardDescription>Open any job to view outputs in accessible formats.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {jobsQuery.isLoading ? (
                <p className="text-sm text-muted-foreground">Loading…</p>
              ) : jobsQuery.data?.length ? (
                <ul className="space-y-3">
                  {jobsQuery.data.map((j) => (
                    <li key={j.id} className="rounded-md border p-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{j.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(j.created_at).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
                          </p>
                        </div>
                        <Badge variant={statusTone(j.status) as any}>{j.status}</Badge>
                      </div>
                      <div className="mt-3 space-y-2">
                        <Progress value={j.progress} />
                        {j.error_message ? <p className="text-xs text-destructive">{j.error_message}</p> : null}
                        <div className="flex justify-end gap-2">
                          <Button asChild variant="outline" size="sm">
                            <Link to={`/jobs/${j.id}`}>Open</Link>
                          </Button>

                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm" disabled={deleteJob.isPending}>
                                {deleteJob.isPending && (deleteJob.variables as any)?.id === j.id ? "Deleting…" : "Delete upload"}
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete this upload?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete the uploaded file, the job, and any generated study materials.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteJob.mutate(j)}>Delete</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="rounded-md border p-4">
                  <p className="text-sm font-medium">No jobs yet</p>
                  <p className="mt-1 text-sm text-muted-foreground">Create your first upload to generate study materials.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </main>
    </AppShell>
  );
}
