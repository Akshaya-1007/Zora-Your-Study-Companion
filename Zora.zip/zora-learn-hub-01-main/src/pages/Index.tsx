// Update this page (the content is just a fallback if you fail to update the page)

import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-primary">
        <div className="mx-auto flex max-w-6xl items-center justify-end px-6 py-4">
          <Button asChild>
            <Link to="/auth">Sign in</Link>
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-12">
        <section className="grid gap-10 lg:grid-cols-12">
          <div className="space-y-5 lg:col-span-7">
            <h1 className="text-balance text-4xl font-semibold tracking-tight md:text-5xl font-sans">
              Zora: Your Study Companion
            </h1>
            <p className="max-w-prose text-pretty text-base text-muted-foreground md:text-lg">
              A Platform designed specifically to support deaf, non-verbal and both students in self-study and exam preparation.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/app">Open dashboard</Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/auth">Create account</Link>
              </Button>
            </div>
            
          </div>

          <div className="lg:col-span-5">
            <Card>
              <CardHeader>
                <CardTitle>What you get</CardTitle>
                <CardDescription>Generated outputs are readable, structured, and easy to review.</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" aria-hidden="true" />
                    Notes with key points, glossary, and exam questions
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" aria-hidden="true" />
                    Flashcards for spaced repetition
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" aria-hidden="true" />
                    Multiple-choice quizzes with explanations
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" aria-hidden="true" />
                    Visual diagram (Mermaid) + alt text
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
};
export default Index;