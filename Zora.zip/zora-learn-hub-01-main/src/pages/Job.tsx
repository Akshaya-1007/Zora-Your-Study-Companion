import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NotesView } from "@/components/job/NotesView";
import { FlashcardsView } from "@/components/job/FlashcardsView";
import { QuizView } from "@/components/job/QuizView";
import { DiagramView } from "@/components/job/DiagramView";

type ArtifactRow = {
  id: string;
  kind: string;
  title: string;
  content: any;
  created_at: string;
};

type JobRow = {
  id: string;
  title: string;
  status: string;
  progress: number;
  error_message: string | null;
  created_at: string;
};

export default function JobPage() {
  const { id } = useParams();

  const jobQuery = useQuery({
    queryKey: ["zora_job", id],
    enabled: Boolean(id),
    queryFn: async (): Promise<JobRow | null> => {
      const { data, error } = await supabase
        .from("zora_jobs")
        .select("id,title,status,progress,error_message,created_at")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return (data as JobRow) ?? null;
    },
  });

  const artifactsQuery = useQuery({
    queryKey: ["zora_artifacts", id],
    enabled: Boolean(id),
    queryFn: async (): Promise<ArtifactRow[]> => {
      const { data, error } = await supabase
        .from("zora_artifacts")
        .select("id,kind,title,content,created_at")
        .eq("job_id", id)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as ArtifactRow[];
    },
  });

  const byKind = (kind: string) => artifactsQuery.data?.find((a) => a.kind === kind)?.content;

  return (
    <AppShell>
      <main className="space-y-6">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate text-2xl font-semibold tracking-tight">{jobQuery.data?.title ?? "Job"}</h1>
            <p className="text-sm text-muted-foreground">
              Status: {jobQuery.data?.status ?? "—"} · Progress: {jobQuery.data?.progress ?? 0}%
            </p>
            {jobQuery.data?.error_message ? <p className="mt-2 text-sm text-destructive">{jobQuery.data.error_message}</p> : null}
          </div>
          <Button asChild variant="outline">
            <Link to="/app">Back</Link>
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Study materials</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="notes" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
                <TabsTrigger value="notes">Notes</TabsTrigger>
                <TabsTrigger value="flashcards">Flashcards</TabsTrigger>
                <TabsTrigger value="quiz">Quiz</TabsTrigger>
                <TabsTrigger value="diagram">Diagram</TabsTrigger>
              </TabsList>

              <TabsContent value="notes" className="mt-4">
                {byKind("notes") ? <NotesView content={byKind("notes")} /> : <p className="text-sm text-muted-foreground">No notes yet.</p>}
              </TabsContent>

              <TabsContent value="flashcards" className="mt-4">
                {byKind("flashcards") ? (
                  <FlashcardsView content={byKind("flashcards")} />
                ) : (
                  <p className="text-sm text-muted-foreground">No flashcards yet.</p>
                )}
              </TabsContent>

              <TabsContent value="quiz" className="mt-4">
                {byKind("quiz") ? <QuizView content={byKind("quiz")} /> : <p className="text-sm text-muted-foreground">No quiz yet.</p>}
              </TabsContent>

              <TabsContent value="diagram" className="mt-4">
                {byKind("diagram") ? (
                  <DiagramView jobId={id!} content={byKind("diagram")} />
                ) : (
                  <p className="text-sm text-muted-foreground">No diagram yet.</p>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </AppShell>
  );
}
