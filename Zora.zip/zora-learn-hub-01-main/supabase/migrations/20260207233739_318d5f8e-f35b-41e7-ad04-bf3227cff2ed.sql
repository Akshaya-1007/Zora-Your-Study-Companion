-- Zora MVP: jobs + generated study artifacts

-- 1) Utility trigger function for updated_at
create or replace function public.zora_set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- 2) Jobs table: one upload -> one processing run
create table if not exists public.zora_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  title text not null,
  source_type text not null default 'upload',
  storage_bucket text not null default 'zora-uploads',
  storage_path text not null,
  mime_type text,
  status text not null default 'queued',
  progress int not null default 0,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists zora_jobs_user_id_idx on public.zora_jobs(user_id);
create index if not exists zora_jobs_status_idx on public.zora_jobs(status);

create trigger zora_jobs_set_updated_at
before update on public.zora_jobs
for each row
execute function public.zora_set_updated_at();

alter table public.zora_jobs enable row level security;

-- Policies: only owner can CRUD their jobs
create policy "zora_jobs_select_own"
on public.zora_jobs
for select
using (auth.uid() = user_id);

create policy "zora_jobs_insert_own"
on public.zora_jobs
for insert
with check (auth.uid() = user_id);

create policy "zora_jobs_update_own"
on public.zora_jobs
for update
using (auth.uid() = user_id);

create policy "zora_jobs_delete_own"
on public.zora_jobs
for delete
using (auth.uid() = user_id);

-- 3) Artifacts table: notes/flashcards/quizzes/diagrams for accessibility
create table if not exists public.zora_artifacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  job_id uuid not null references public.zora_jobs(id) on delete cascade,
  kind text not null, -- notes | flashcards | quiz | diagram
  title text not null,
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists zora_artifacts_user_id_idx on public.zora_artifacts(user_id);
create index if not exists zora_artifacts_job_id_idx on public.zora_artifacts(job_id);
create index if not exists zora_artifacts_kind_idx on public.zora_artifacts(kind);

create trigger zora_artifacts_set_updated_at
before update on public.zora_artifacts
for each row
execute function public.zora_set_updated_at();

alter table public.zora_artifacts enable row level security;

create policy "zora_artifacts_select_own"
on public.zora_artifacts
for select
using (auth.uid() = user_id);

create policy "zora_artifacts_insert_own"
on public.zora_artifacts
for insert
with check (auth.uid() = user_id);

create policy "zora_artifacts_update_own"
on public.zora_artifacts
for update
using (auth.uid() = user_id);

create policy "zora_artifacts_delete_own"
on public.zora_artifacts
for delete
using (auth.uid() = user_id);

-- 4) Storage bucket + policies (store files in storage, NOT DB)
-- Bucket
insert into storage.buckets (id, name, public)
values ('zora-uploads', 'zora-uploads', false)
on conflict (id) do nothing;

-- Objects RLS policies: only owner can read/write their own folder (user_id as first segment)
create policy "zora_uploads_read_own"
on storage.objects
for select
using (
  bucket_id = 'zora-uploads'
  and auth.uid()::text = (storage.foldername(name))[1]
);

create policy "zora_uploads_insert_own"
on storage.objects
for insert
with check (
  bucket_id = 'zora-uploads'
  and auth.uid()::text = (storage.foldername(name))[1]
);

create policy "zora_uploads_update_own"
on storage.objects
for update
using (
  bucket_id = 'zora-uploads'
  and auth.uid()::text = (storage.foldername(name))[1]
);

create policy "zora_uploads_delete_own"
on storage.objects
for delete
using (
  bucket_id = 'zora-uploads'
  and auth.uid()::text = (storage.foldername(name))[1]
);
