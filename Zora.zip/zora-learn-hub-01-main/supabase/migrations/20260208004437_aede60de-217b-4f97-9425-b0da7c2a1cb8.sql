-- Create a private bucket for generated diagrams
insert into storage.buckets (id, name, public)
values ('zora-diagrams', 'zora-diagrams', false)
on conflict (id) do nothing;

-- RLS policies for diagram objects (per-user folder)
-- Users can read their own diagram images
create policy "Users can read own diagram images"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'zora-diagrams'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can upload their own diagram images
create policy "Users can upload own diagram images"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'zora-diagrams'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can update their own diagram images
create policy "Users can update own diagram images"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'zora-diagrams'
  and auth.uid()::text = (storage.foldername(name))[1]
)
with check (
  bucket_id = 'zora-diagrams'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can delete their own diagram images
create policy "Users can delete own diagram images"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'zora-diagrams'
  and auth.uid()::text = (storage.foldername(name))[1]
);