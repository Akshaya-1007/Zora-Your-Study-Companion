// Generate an infographic-style PNG for an existing job's diagram artifact
// - Auth required
// - Reads existing diagram (mermaid + alt_text) from zora_artifacts
// - Generates PNG via Lovable AI image model
// - Uploads to zora-diagrams/{userId}/{jobId}/diagram.png
// - Updates artifact content with image_bucket + image_path

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type DiagramImageResult = {
  imageDataUrl: string;
};

async function callLovableDiagramImage(params: {
  title: string;
  transcript?: string | null;
  diagramAltText?: string | null;
  diagramMermaid?: string | null;
}): Promise<DiagramImageResult> {
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
  if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

  const prompt =
    "Create ONE clean educational infographic diagram as a PNG image. " +
    "It should look like a mix of: visual infographic + whiteboard + presentation slide. " +
    "Use: boxes, arrows, simple icons, clear headings, and good spacing. " +
    "No clutter, no tiny text, high readability. Use a light background.\n\n" +
    `Topic: ${params.title}\n\n` +
    (params.diagramAltText ? `Diagram description (alt text):\n${params.diagramAltText}\n\n` : "") +
    (params.diagramMermaid ? `Structure (Mermaid):\n${params.diagramMermaid}\n\n` : "") +
    (params.transcript ? `Transcript (for accuracy):\n${params.transcript}\n\n` : "") +
    "Output: return an image only.";

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash-image",
      messages: [{ role: "user", content: prompt }],
      modalities: ["image", "text"],
      temperature: 0.3,
    }),
  });

  if (!resp.ok) {
    const t = await resp.text();
    if (resp.status === 429) throw new Error("AI rate limit exceeded (429). Please try again soon.");
    if (resp.status === 402) throw new Error("AI credits exhausted (402). Please add credits to continue.");
    throw new Error(`AI gateway error [${resp.status}]: ${t.slice(0, 600)}`);
  }

  const data = await resp.json();
  const imageUrl = data?.choices?.[0]?.message?.images?.[0]?.image_url?.url as string | undefined;
  if (!imageUrl) throw new Error("AI image generation returned no image");
  return { imageDataUrl: imageUrl };
}

function dataUrlToBytes(dataUrl: string): { bytes: Uint8Array; contentType: string } {
  const match = dataUrl.match(/^data:([^;]+);base64,(.*)$/);
  if (!match) throw new Error("Invalid image data URL");
  const contentType = match[1];
  const b64 = match[2];
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return { bytes, contentType };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");
    if (!SUPABASE_URL) throw new Error("SUPABASE_URL is not configured");
    if (!SUPABASE_ANON_KEY) throw new Error("SUPABASE_ANON_KEY is not configured");

    const authHeader = req.headers.get("Authorization") ?? "";

    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const {
      data: { user },
      error: userErr,
    } = await supabase.auth.getUser();

    if (userErr) throw userErr;
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders } });

    const body = await req.json();
    const jobId = body?.jobId as string | undefined;
    if (!jobId) return new Response(JSON.stringify({ error: "Missing jobId" }), { status: 400, headers: { ...corsHeaders } });

    const { data: job, error: jobErr } = await supabase
      .from("zora_jobs")
      .select("id,user_id,title")
      .eq("id", jobId)
      .maybeSingle();

    if (jobErr) throw jobErr;
    if (!job) return new Response(JSON.stringify({ error: "Job not found" }), { status: 404, headers: { ...corsHeaders } });
    if (job.user_id !== user.id) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders } });

    const { data: artifact, error: artErr } = await supabase
      .from("zora_artifacts")
      .select("id,content")
      .eq("job_id", jobId)
      .eq("kind", "diagram")
      .maybeSingle();

    if (artErr) throw artErr;
    if (!artifact) return new Response(JSON.stringify({ error: "Diagram artifact not found" }), { status: 404, headers: { ...corsHeaders } });

    const content = (artifact as any).content ?? {};
    const diagramAltText = content?.alt_text ?? null;
    const diagramMermaid = content?.mermaid ?? null;

    console.log("Generating diagram image", { userId: user.id, jobId });

    const diagramImage = await callLovableDiagramImage({
      title: job.title,
      diagramAltText,
      diagramMermaid,
    });

    const diagramObjectPath = `${user.id}/${jobId}/diagram.png`;
    const { bytes, contentType } = dataUrlToBytes(diagramImage.imageDataUrl);

    const upload = await supabase.storage
      .from("zora-diagrams")
      .upload(diagramObjectPath, bytes, { contentType, upsert: true });

    if (upload.error) throw upload.error;

    const nextContent = {
      ...content,
      image_bucket: "zora-diagrams",
      image_path: diagramObjectPath,
    };

    const { error: updErr } = await supabase.from("zora_artifacts").update({ content: nextContent }).eq("id", artifact.id);
    if (updErr) throw updErr;

    return new Response(JSON.stringify({ ok: true, image_bucket: "zora-diagrams", image_path: diagramObjectPath }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error("zora-diagram-image error", e);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
