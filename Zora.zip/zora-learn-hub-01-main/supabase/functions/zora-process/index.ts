// Zora processing function: generate accessible study outputs
// - Auth required
// - Reads job + signed file URL
// - Uses Lovable AI gateway to produce notes/flashcards/quiz/diagram

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type GenerateResult = {
  notes: any;
  flashcards: any;
  quiz: any;
  diagram: any;
};

type DiagramImageResult = {
  imageDataUrl: string;
};

type WhisperResult = {
  text: string;
  language?: string;
  duration?: number;
};

function getRequiredEnv(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`${name} is not configured`);
  return v;
}

async function callLovableAI(params: { title: string; transcript?: string | null }): Promise<GenerateResult> {
  const LOVABLE_API_KEY = getRequiredEnv("LOVABLE_API_KEY");

  const system =
    "You are Zora, an accessibility-first study assistant for deaf and non-verbal learners. " +
    "Generate clear, structured learning materials. Avoid fluff. Use plain language.";

  const userPrompt =
    `Create accessible study outputs for: ${params.title}.\n\n` +
    (params.transcript
      ? `Transcript:\n${params.transcript}\n\n`
      : "No transcript was provided. Make reasonable assumptions, and keep the output generic and safe.\n\n") +
    "Return a single JSON object with keys: notes, flashcards, quiz, diagram.\n" +
    "- notes: {summary: string, key_points: string[], glossary: {term:string, definition:string}[], exam_questions: string[]}\n" +
    "- flashcards: {cards: {front:string, back:string}[]}\n" +
    "- quiz: {questions: {q:string, choices:string[], answer_index:number, explanation:string}[]}\n" +
    "- diagram: {mermaid:string, alt_text:string} (mermaid flowchart preferred)";

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-3-flash-preview",
      messages: [
        { role: "system", content: system },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.4,
    }),
  });

  if (!resp.ok) {
    const t = await resp.text();
    if (resp.status === 429) throw new Error("AI rate limit exceeded (429). Please try again soon.");
    if (resp.status === 402) throw new Error("AI credits exhausted (402). Please add credits to continue.");
    throw new Error(`AI gateway error [${resp.status}]: ${t.slice(0, 600)}`);
  }

  const data = await resp.json();
  const content = data?.choices?.[0]?.message?.content as string | undefined;
  if (!content) throw new Error("AI gateway returned no content");

  // Best-effort JSON extraction
  const jsonStart = content.indexOf("{");
  const jsonEnd = content.lastIndexOf("}");
  if (jsonStart === -1 || jsonEnd === -1) throw new Error("AI output was not JSON");

  const parsed = JSON.parse(content.slice(jsonStart, jsonEnd + 1));
  return parsed as GenerateResult;
}

async function callLovableDiagramImage(params: {
  title: string;
  transcript?: string | null;
  diagramAltText?: string | null;
  diagramMermaid?: string | null;
}): Promise<DiagramImageResult> {
  const LOVABLE_API_KEY = getRequiredEnv("LOVABLE_API_KEY");

  const prompt =
    "Create ONE clean educational infographic diagram as a PNG image. " +
    "It should look like a mix of: visual infographic + whiteboard + presentation slide. " +
    "Use: boxes, arrows, simple icons, clear headings, and good spacing. " +
    "No clutter, no tiny text, high readability. Use a light background.\n\n" +
    `Topic: ${params.title}\n\n` +
    (params.diagramAltText ? `Diagram description (alt text):\n${params.diagramAltText}\n\n` : "") +
    (params.diagramMermaid ? `Structure (Mermaid):\n${params.diagramMermaid}\n\n` : "") +
    (params.transcript ? `Transcript (for accuracy):\n${params.transcript}\n\n` : "") +
    "Output: return an image only.";

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash-image",
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
      modalities: ["image", "text"],
      temperature: 0.3,
    }),
  });

  if (!resp.ok) {
    const t = await resp.text();
    if (resp.status === 429) throw new Error("AI rate limit exceeded (429). Please try again soon.");
    if (resp.status === 402) throw new Error("AI credits exhausted (402). Please add credits to continue.");
    throw new Error(`AI gateway error [${resp.status}]: ${t.slice(0, 600)}`);
  }

  const data = await resp.json();
  const imageUrl = data?.choices?.[0]?.message?.images?.[0]?.image_url?.url as string | undefined;
  if (!imageUrl) throw new Error("AI image generation returned no image");

  return { imageDataUrl: imageUrl };
}

async function transcribeViaWhisper(params: {
  url: string;
  contentType?: string | null;
  filename?: string;
}): Promise<WhisperResult> {
  const WHISPER_STT_URL = getRequiredEnv("WHISPER_STT_URL").replace(/\/$/, "");
  const WHISPER_STT_TOKEN = getRequiredEnv("WHISPER_STT_TOKEN");

  const acDownload = new AbortController();
  const dlTimeout = setTimeout(() => acDownload.abort("download-timeout"), 3 * 60_000);
  const dlResp = await fetch(params.url, { signal: acDownload.signal });
  clearTimeout(dlTimeout);

  if (!dlResp.ok) {
    const t = await dlResp.text().catch(() => "");
    throw new Error(`Could not download uploaded media for transcription [${dlResp.status}]: ${t.slice(0, 200)}`);
  }

  const bytes = new Uint8Array(await dlResp.arrayBuffer());
  const blob = new Blob([bytes], { type: params.contentType ?? "application/octet-stream" });

  const form = new FormData();
  form.append("file", blob, params.filename ?? "upload.bin");

  const ac = new AbortController();
  const timeout = setTimeout(() => ac.abort("whisper-timeout"), 6 * 60_000);
  const resp = await fetch(`${WHISPER_STT_URL}/transcribe`, {
    method: "POST",
    headers: {
      "x-whisper-token": WHISPER_STT_TOKEN,
    },
    body: form,
    signal: ac.signal,
  });
  clearTimeout(timeout);

  if (!resp.ok) {
    const t = await resp.text().catch(() => "");
    throw new Error(`Whisper transcription failed [${resp.status}]: ${t.slice(0, 600)}`);
  }

  const data = (await resp.json()) as WhisperResult;
  if (!data?.text?.trim()) throw new Error("Whisper returned no text");
  return data;
}

function dataUrlToBytes(dataUrl: string): { bytes: Uint8Array; contentType: string } {
  const match = dataUrl.match(/^data:([^;]+);base64,(.*)$/);
  if (!match) throw new Error("Invalid image data URL");
  const contentType = match[1];
  const b64 = match[2];
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return { bytes, contentType };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");
    if (!SUPABASE_URL) throw new Error("SUPABASE_URL is not configured");
    if (!SUPABASE_ANON_KEY) throw new Error("SUPABASE_ANON_KEY is not configured");

    const authHeader = req.headers.get("Authorization") ?? "";

    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: {
        headers: {
          Authorization: authHeader,
        },
      },
    });

    const {
      data: { user },
      error: userErr,
    } = await supabase.auth.getUser();

    if (userErr) throw userErr;
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders } });

    const body = await req.json();
    const jobId = body?.jobId as string | undefined;
    const transcript = (body?.transcript as string | null | undefined) ?? null;

    if (!jobId) return new Response(JSON.stringify({ error: "Missing jobId" }), { status: 400, headers: { ...corsHeaders } });

    const { data: job, error: jobErr } = await supabase
      .from("zora_jobs")
      .select("id,user_id,title,storage_bucket,storage_path,status")
      .eq("id", jobId)
      .maybeSingle();
    if (jobErr) throw jobErr;
    if (!job) return new Response(JSON.stringify({ error: "Job not found" }), { status: 404, headers: { ...corsHeaders } });
    if (job.user_id !== user.id) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders } });

    // Update status
    await supabase.from("zora_jobs").update({ status: "processing", progress: 10, error_message: null }).eq("id", jobId);

    // Create signed URL to fetch the uploaded media
    const signed = await supabase.storage.from(job.storage_bucket).createSignedUrl(job.storage_path, 60 * 10);
    if (signed.error) {
      console.warn("signed url error", signed.error);
    }

    // Transcribe if transcript not provided
    let effectiveTranscript = transcript;
    if (!effectiveTranscript?.trim()) {
      await supabase.from("zora_jobs").update({ progress: 20 }).eq("id", jobId);

      const signedUrl = signed.data?.signedUrl;
      if (!signedUrl) {
        console.warn("No signedUrl available; continuing without transcript");
      } else {
        try {
          const filename = (job.storage_path?.split("/").pop() || "upload.bin").slice(0, 180);
          const whisper = await transcribeViaWhisper({
            url: signedUrl,
            contentType: (job as any).mime_type ?? null,
            filename,
          });
          effectiveTranscript = whisper.text;
        } catch (err) {
          console.warn("Whisper transcription failed; continuing with generic generation", err);
          // Keep going: generation can work without transcript.
        }
      }
    }

    // Generate outputs
    await supabase.from("zora_jobs").update({ progress: 40 }).eq("id", jobId);

    const generated = await callLovableAI({ title: job.title, transcript: effectiveTranscript });

    // Create a real infographic-style diagram image (PNG)
    await supabase.from("zora_jobs").update({ progress: 70 }).eq("id", jobId);

    const diagramAltText = (generated as any)?.diagram?.alt_text ?? null;
    const diagramMermaid = (generated as any)?.diagram?.mermaid ?? null;

    const diagramImage = await callLovableDiagramImage({
      title: job.title,
      transcript: effectiveTranscript,
      diagramAltText,
      diagramMermaid,
    });

    const diagramObjectPath = `${user.id}/${jobId}/diagram.png`;
    const { bytes, contentType } = dataUrlToBytes(diagramImage.imageDataUrl);

    const upload = await supabase.storage
      .from("zora-diagrams")
      .upload(diagramObjectPath, bytes, { contentType, upsert: true });

    if (upload.error) throw upload.error;

    await supabase.from("zora_jobs").update({ progress: 80 }).eq("id", jobId);

    const artifacts = [
      { kind: "notes", title: "Notes", content: generated.notes },
      { kind: "flashcards", title: "Flashcards", content: generated.flashcards },
      { kind: "quiz", title: "Quiz", content: generated.quiz },
      {
        kind: "diagram",
        title: "Diagram",
        content: {
          alt_text: diagramAltText,
          mermaid: diagramMermaid,
          image_bucket: "zora-diagrams",
          image_path: diagramObjectPath,
        },
      },
    ].map((a) => ({ ...a, user_id: user.id, job_id: jobId }));

    const { error: artErr } = await supabase.from("zora_artifacts").insert(artifacts);
    if (artErr) throw artErr;

    await supabase.from("zora_jobs").update({ status: "complete", progress: 100 }).eq("id", jobId);

    return new Response(JSON.stringify({ ok: true, signedUrl: signed.data?.signedUrl ?? null }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error("zora-process error", e);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
